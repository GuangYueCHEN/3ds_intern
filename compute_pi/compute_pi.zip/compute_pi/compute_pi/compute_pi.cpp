
#include "pch.h"
#include <iostream>
#include "functions.h"

using namespace std;
  

int main()
{
	double res = compute_pi(100);
    cout << "Pi with 100 iteration is " <<res <<"\n"; 
	system("pause");
	return 0;
}
